﻿using UnityEngine;
using System.Collections;
using UnityEngine.Networking;

public class LevelMessage : MessageBase {
	public int width;
	public int height;
	public string message;
}
